import RPi.GPIO as GPIO

pins = [{'pin_num': 9, 'name': 'd1'},
        {'pin_num': 8, 'name': 'd2'},
        {'pin_num': 7, 'name': 'd3'},
        {'pin_num': 1, 'name': 'd4'}]

GPIO.setmode(GPIO.BCM)  # use GPIO numbering, not generic
GPIO.setwarnings(False)
GPIO.setup(12, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)
p1 = GPIO.PWM(12,1000)
p2 = GPIO.PWM(13,1000)
p1.start(0)
p2.start(0)
# set up PWMs for servo motors
GPIO.setup(18, GPIO.OUT)
step1 = GPIO.PWM(18,50)
step1.start(0)
# do other 2 steppers

# setup all logic pins based on above configuration
for pin in pins:
    GPIO.setup(pin['pin_num'], GPIO.OUT, initial=GPIO.LOW)

def set(name, state):
    pin_nums = [pin['pin_num'] for pin in pins if pin['name'] == name]
    for pin_num in pin_nums:
        if state == 'on':
            GPIO.output(pin_num, GPIO.HIGH)
        elif state == 'off':
            GPIO.output(pin_num, GPIO.LOW)

def coast():
    print("coast")
    for pin in pins:
        GPIO.output(pin['pin_num'], GPIO.LOW)
