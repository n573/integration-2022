from time import sleep
import stepper as step

step.setAngle(180)
sleep(3)
step.closeOut()
